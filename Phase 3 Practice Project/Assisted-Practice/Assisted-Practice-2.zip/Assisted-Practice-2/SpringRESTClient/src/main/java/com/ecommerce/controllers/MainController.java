package com.ecommerce.controllers;

import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
public class MainController {

    @RequestMapping("/")
    @ResponseBody
    public String index() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new StringHttpMessageConverter());
        String quote = restTemplate.getForObject("https://type.fit/api/quotes", String.class);
        return quote;
    }
}

