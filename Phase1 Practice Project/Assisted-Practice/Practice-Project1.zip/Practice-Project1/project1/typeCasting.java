package project1;

class typeCasting {
	public static void main(String args[]) {
	
		//Implicit type casting example

		System.out.println("Examples for Implicit type casting");
		byte a=10;
		short b=a;  //implicit type casting example 1
			System.out.println("Example 1");
			System.out.println("Original byte Value "+a);
			System.out.println("Value after converting byte to short "+b);
			System.out.println("\n");

		int c=100;
		float d=c;  //implicit type casting example 2
			System.out.println("Example 2");
			System.out.println("Original int value "+c);
			System.out.println("Value after converting from int to float "+d);
			System.out.println("\n");

		System.out.println("\n");
		
		//Explicit type casting example
		
		System.out.println("Examples for explicit type casting");
		short e=10;
		byte f =(byte)e;  // explicit type casting example 1

			System.out.println("Example 1");
			System.out.println("Original short value "+e);
			System.out.println("Value after converting byte to short "+f);
			System.out.println("\n");

			float x = 100.113f;
			int y = (int)x;	  // explicit type casting example 2
			System.out.println("Example 2");	
			System.out.println("Original float value "+x);
			System.out.println("Value after converting float to int "+y);
	}
}
