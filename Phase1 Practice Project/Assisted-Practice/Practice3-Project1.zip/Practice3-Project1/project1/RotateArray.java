package project1;

public class RotateArray {

    // Function to rotate an array to the right by 'steps' steps
    public static void rightRotate(int[] arr, int steps) {
        int length = arr.length;
        steps = steps % length; // In case the steps are more than the array length
        reverse(arr, 0, length - 1);
        reverse(arr, 0, steps - 1);
        reverse(arr, steps, length - 1);
    }

    // Function to reverse a portion of the array from 'start' to 'end'
    private static void reverse(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }

    // Function to print the elements of the array
    public static void printArray(int[] arr) {
        for (int i : arr) {
            System.out.print(i + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        System.out.println("Original array:");
        printArray(arr);

        rightRotate(arr, 5);
        System.out.println("Array after right rotation by 5 steps:");
        printArray(arr);
    }
}
