package project10;

import java.util.regex.Pattern;

//Main class
class RegEx {

 // Main driver method
 public static void main(String args[])
 {

     System.out.println(Pattern.matches("Va*si", "Vamsi"));
     System.out.println(Pattern.matches("V*am*si", "Kisanja"));
 }
}
