package project3;
public class MyClass {
 
    static void myMethod() {
        System.out.println("You have called me! My name is: myMethod!");
    }
 
    public static void main(String[] args) {
        myMethod();
    }
}