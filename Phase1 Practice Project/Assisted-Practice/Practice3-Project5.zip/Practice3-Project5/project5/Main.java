package project5;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SinglyLinkedList {
    Node head;

    // Method to add element at the end of the list
    public void add(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Method to delete the first occurrence of a key
    public void deleteFirstOccurrence(int key) {
        Node current = head, prev = null;
        
        // If the head node itself holds the key
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        // Search for the key to be deleted
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key was not present in the list
        if (current == null) {
            System.out.println("Key " + key + " not found.");
            return;
        }

        // Unlink the node from the linked list
        prev.next = current.next;
    }

    // Method to print the list
    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class Main {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(2);
        list.add(4);

        System.out.println("Original list:");
        list.printList();

        int keyToDelete = 2;
        list.deleteFirstOccurrence(keyToDelete);
        System.out.println("List after deleting first occurrence of " + keyToDelete + ":");
        list.printList();
    }
}
