package project9;


import java.util.LinkedList;
import java.util.NoSuchElementException;

public class QueueExample {
    private LinkedList<Integer> queue;

    public QueueExample() {
        queue = new LinkedList<>();
    }

    // Method to insert an element into the queue
    public void enqueue(int element) {
        queue.addLast(element);
        System.out.println(element + " added to the queue");
    }

    // Method to remove an element from the queue
    public int dequeue() {
        try {
            int removedElement = queue.removeFirst();
            System.out.println(removedElement + " removed from the queue");
            return removedElement;
        } catch (NoSuchElementException e) {
            throw new NoSuchElementException("Queue is empty, cannot dequeue");
        }
    }

    // Method to display the elements of the queue
    public void display() {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty");
        } else {
            System.out.println("Queue elements: " + queue);
        }
    }

    public static void main(String[] args) {
        QueueExample myQueue = new QueueExample();

        // Enqueue elements
        myQueue.enqueue(10);
        myQueue.enqueue(20);
        myQueue.enqueue(30);

        // Display elements
        myQueue.display();

        // Dequeue elements
        myQueue.dequeue();
        myQueue.dequeue();

        // Display elements after dequeuing
        myQueue.display();
    }
}
