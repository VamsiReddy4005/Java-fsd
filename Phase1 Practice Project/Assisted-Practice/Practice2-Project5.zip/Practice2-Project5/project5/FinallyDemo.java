package project5;
import java.util.Scanner;

public class FinallyDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.println("Enter a number:");
            int number = scanner.nextInt();
            int result = 10 / number;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero!");
        } finally {
            // This block will always execute regardless of whether an exception occurs or not
            System.out.println("Finally block executed.");
            scanner.close(); // Closing scanner resource
        }
    }
}
