package project5;

class MyCustomException extends Exception {
    public MyCustomException(String message) {
        super(message);
    }
}

public class CustomExceptionDemo {
    public static void main(String[] args) {
        try {
            int age = 17;
            if (age < 18) {
                throw new MyCustomException("Age must be 18 or above for registration.");
            } else {
                System.out.println("Registration successful!");
            }
        } catch (MyCustomException e) {
            System.out.println("Custom Exception Caught: " + e.getMessage());
        }
    }
}
