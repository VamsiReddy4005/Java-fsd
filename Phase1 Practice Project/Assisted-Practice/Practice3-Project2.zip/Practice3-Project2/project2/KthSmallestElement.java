package project2;


public class KthSmallestElement {

    private static void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++;
                swap(arr, i, j);
            }
        }
        swap(arr, i + 1, high);
        return i + 1;
    }

    private static int quickSelect(int[] arr, int low, int high, int k) {
        if (k > 0 && k <= high - low + 1) {
            int pos = partition(arr, low, high);
            
           
            if (pos - low == k - 1) {
                return arr[pos];
            }
            
           
            if (pos - low > k - 1) {
                return quickSelect(arr, low, pos - 1, k);
            }
            
           
            return quickSelect(arr, pos + 1, high, k - pos + low - 1);
        }
        
       
        return Integer.MAX_VALUE;
    }


    public static int findKthSmallest(int[] arr, int k) {
        return quickSelect(arr, 0, arr.length - 1, k);
    }

    public static void main(String[] args) {
        int[] arr = {10, 4, 5, 8, 6, 11, 26};
        int k = 4; 
        System.out.println("The " + k + "th smallest element is " + findKthSmallest(arr, k));
    }
}
