package project6;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    // Method to insert a new element in a sorted circular linked list
    public void insertSorted(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (data <= head.data) {
            // Insertion before the head for smallest element
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode; // Update head to new node for smallest element
        } else {
            // Find position to insert
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Method to print the circular linked list
    public void printList() {
        if (head != null) {
            Node current = head;
            do {
                System.out.print(current.data + " ");
                current = current.next;
            } while (current != head);
            System.out.println();
        }
    }
}

public class LinkedList {
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        list.insertSorted(40);
        list.insertSorted(20);
        list.insertSorted(60);
        list.insertSorted(10);
        list.insertSorted(50);
        list.insertSorted(30);

        System.out.println("Sorted Circular Linked List:");
        list.printList();
    }
}
