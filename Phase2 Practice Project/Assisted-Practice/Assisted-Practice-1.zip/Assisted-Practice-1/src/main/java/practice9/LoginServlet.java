package practice9;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        // Retrieve username from the request
        String username = req.getParameter("username");
        String action = req.getParameter("action");

        HttpSession session = req.getSession();

        if ("login".equalsIgnoreCase(action)) {
            // Login action
            if (username != null && !username.trim().isEmpty()) {
                session.setAttribute("username", username);
                out.println("<h2>Welcome, " + username + "</h2>");
                out.println("<a href='login?action=logout'>Logout</a>");
            } else {
                out.println("<h2>Please enter a valid username!</h2>");
                out.println("<a href='login.html'>Try again</a>");
            }
        } else if ("logout".equalsIgnoreCase(action)) {
            // Logout action
            session.invalidate();
            out.println("<h2>You have been logged out.</h2>");
            out.println("<a href='login.html'>Login again</a>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Redirect POST to handle login and logout
        doPost(req, resp);
    }
}
