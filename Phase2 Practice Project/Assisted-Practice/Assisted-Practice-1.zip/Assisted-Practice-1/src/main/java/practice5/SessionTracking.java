package practice5;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/visitCounter")
public class SessionTracking extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        
        // Default visit count is 1
        int visitCount = 1;
        
        // Check if the "visitCount" cookie is present
        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("visitCount".equals(cookie.getName())) {
                    // Parse the visit count from the cookie and increment it
                    visitCount = Integer.parseInt(cookie.getValue()) + 1;
                    break;
                }
            }
        }
        
        // Update the "visitCount" cookie with the new count
        Cookie visitCountCookie = new Cookie("visitCount", Integer.toString(visitCount));
        visitCountCookie.setMaxAge(24 * 60 * 60); // Expires in 24 hours
        resp.addCookie(visitCountCookie);
        
        // Generate the HTML response
        PrintWriter out = resp.getWriter();
        out.println("<html><body>");
        out.println("<h2>You have visited this page " + visitCount + " times.</h2>");
        out.println("</body></html>");
    }
}
