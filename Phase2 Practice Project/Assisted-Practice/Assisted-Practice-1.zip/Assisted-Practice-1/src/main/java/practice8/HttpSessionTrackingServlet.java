package practice8;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/sessionTracker")
public class HttpSessionTrackingServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");

        // Retrieve or create a session for the user
        HttpSession session = req.getSession();

        // Retrieve or initialize the visit count stored in the session
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 1;
        } else {
            visitCount++;
        }

        // Update the visit count attribute in the session
        session.setAttribute("visitCount", visitCount);

        // Generate the response HTML
        PrintWriter out = resp.getWriter();
        out.println("<html><body>");
        out.println("<h2>You have visited this page " + visitCount + " times in this session.</h2>");
        out.println("</body></html>");
    }
}
