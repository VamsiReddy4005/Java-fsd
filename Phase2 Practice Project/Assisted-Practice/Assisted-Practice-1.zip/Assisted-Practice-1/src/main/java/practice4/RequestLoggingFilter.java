package practice4;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;


@WebFilter("/*") // Apply filter to all requests
public class RequestLoggingFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("RequestLoggingFilter initialized");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        long startTime = System.currentTimeMillis();
        System.out.println("Request Received: " + request.getRemoteAddr());
        System.out.println("Servlet Path: " + ((HttpServletRequest) request).getServletPath());
        
        chain.doFilter(request, response);
        
        long endTime = System.currentTimeMillis();
        System.out.println("Request Processed in " + (endTime - startTime) + " ms");
    }

    @Override
    public void destroy() {
        System.out.println("RequestLoggingFilter destroyed");
    }
}
