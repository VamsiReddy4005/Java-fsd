package practice2;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ExampleGenericServlet", urlPatterns = {"/generic"})
public class GenericServletDemo extends GenericServlet {

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        // Set the content type of the response
        res.setContentType("text/plain");

        // Get the output writer to write the response
        PrintWriter out = res.getWriter();

        // Write a simple message
        out.println("This is a generic servlet handling a request through annotations.");
    }
}
