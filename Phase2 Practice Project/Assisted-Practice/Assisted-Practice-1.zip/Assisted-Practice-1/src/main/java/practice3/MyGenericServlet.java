package practice3;

import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;

public class MyGenericServlet implements Servlet {
    private ServletConfig config;

    @Override
    public void init(ServletConfig config) throws ServletException {
        this.config = config;
    }

    @Override
    public ServletConfig getServletConfig() {
        return this.config;
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        res.setContentType("text/plain");
        PrintWriter out = res.getWriter();
        out.println("Direct implementation of Servlet interface.");
    }

    @Override
    public String getServletInfo() {
        return "MyGenericServlet";
    }

    @Override
    public void destroy() {
    }
}
