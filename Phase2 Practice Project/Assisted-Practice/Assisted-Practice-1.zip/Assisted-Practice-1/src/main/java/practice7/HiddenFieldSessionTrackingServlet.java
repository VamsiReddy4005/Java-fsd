package practice7;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/hiddenFieldSessionTracker")
public class HiddenFieldSessionTrackingServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        
        // Attempt to get the visit count from hidden form field
        String visitCountStr = req.getParameter("visitCount");
        int visitCount = 1;
        if (visitCountStr != null) {
            try {
                visitCount = Integer.parseInt(visitCountStr) + 1;
            } catch (NumberFormatException e) {
                // Handle potential parsing error, default to 1
                visitCount = 1;
            }
        }

        // Generate the HTML content with form
        PrintWriter out = resp.getWriter();
        out.println("<html><body>");
        out.println("<form action='hiddenFieldSessionTracker' method='POST'>");
        out.println("<input type='hidden' name='visitCount' value='" + visitCount + "'>");
        out.println("<input type='submit' value='Visit Again'>");
        out.println("</form>");
        out.println("<h2>This page has been visited " + visitCount + " times.</h2>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Delegate POST requests to doGet method for simplicity
        doGet(req, resp);
    }
}
