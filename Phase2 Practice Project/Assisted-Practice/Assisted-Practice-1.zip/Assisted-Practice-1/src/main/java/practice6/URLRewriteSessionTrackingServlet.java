package practice6;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/urlSessionTracker")
public class URLRewriteSessionTrackingServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        HttpSession session = req.getSession();

        // Track visit count using session
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 1;
        } else {
            visitCount += 1;
        }
        session.setAttribute("visitCount", visitCount);

        // Generate the HTML content
        PrintWriter out = resp.getWriter();
        out.println("<html><body>");
        out.println("<h2>You have visited this page " + visitCount + " times in this session.</h2>");

        // URL rewriting to append session ID if cookies are disabled
        String url = "urlSessionTracker";
        String encodedURL = resp.encodeURL(url);
        out.println("<a href='" + encodedURL + "'>Visit again</a>");

        out.println("</body></html>");
    }
}
