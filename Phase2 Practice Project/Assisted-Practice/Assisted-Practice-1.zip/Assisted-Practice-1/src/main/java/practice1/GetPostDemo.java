package practice1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/methodDemo")
public class GetPostDemo extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Process request parameters and generate response for GET request
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try {
            int first = Integer.parseInt(request.getParameter("first"));
            int second = Integer.parseInt(request.getParameter("second"));
            int sum = first + second;
            
            out.println("<html><body>");
            out.println("<p>Method: GET</p>");
            out.println("<p>First Number: " + first + "</p>");
            out.println("<p>Second Number: " + second + "</p>");
            out.println("<p>Sum: " + sum + "</p>");
            out.println("</body></html>");
        } catch (NumberFormatException e) {
            out.println("<html><body>");
            out.println("<p>Please enter valid numbers.</p>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Process request parameters and generate response for POST request
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try {
            int first = Integer.parseInt(request.getParameter("first"));
            int second = Integer.parseInt(request.getParameter("second"));
            int sum = first + second;
            
            out.println("<html><body>");
            out.println("<p>Method: POST</p>");
            out.println("<p>First Number: " + first + "</p>");
            out.println("<p>Second Number: " + second + "</p>");
            out.println("<p>Sum: " + sum + "</p>");
            out.println("</body></html>");
        } catch (NumberFormatException e) {
            out.println("<html><body>");
            out.println("<p>Please enter valid numbers.</p>");
            out.println("</body></html>");
        }
    }
}